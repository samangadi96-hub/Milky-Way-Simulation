#version 330

in vec2 v_uv;
// We output to two targets if we use two textures, or one RGBA16F and depth
// Let's output RGBA: RGB = premultiplied emission, A = transmittance.
// And a second output for depth if we use 2 color attachments, OR we can write depth to gl_FragDepth? 
// The FBO setup in main.py will use two color attachments: color (RGBA16F) and frontDepth (R16F)
layout(location = 0) out vec4 fragColor;
layout(location = 1) out float fragDepth;

uniform vec3 u_camPos;
uniform mat4 u_invVP;
uniform mat4 u_galaxyModel; // inverse rotation of galaxy

uniform float u_nebulaWeight;
uniform float u_camDist;
uniform int u_numNebulae;

// Max 150 nebulae
uniform vec4 u_nebulae_pos[150]; // xyz = position, w = radius
uniform vec4 u_nebulae_col[150]; // rgb = color, a = density/emission strength

// ============================================================
// Hash and Noise
// ============================================================

float hash(vec3 p) {
    p = fract(p * 0.3183099 + 0.1);
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float noise(vec3 x) {
    vec3 i = floor(x);
    vec3 f = fract(x);
    f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    return mix(mix(mix(hash(i + vec3(0,0,0)), hash(i + vec3(1,0,0)), f.x),
                   mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
               mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
                   mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
}

float fbm3(vec3 p) {
    float f = 0.0;
    float w = 0.5;
    float totalW = 0.0;
    for (int i = 0; i < 3; i++) {
        f += w * noise(p);
        totalW += w;
        p *= 2.07;
        w *= 0.5;
    }
    return f / totalW;
}

float fbm5(vec3 p) {
    float f = 0.0;
    float w = 0.5;
    float totalW = 0.0;
    for (int i = 0; i < 5; i++) {
        f += w * noise(p);
        totalW += w;
        p *= 2.03;
        w *= 0.48;
    }
    return f / totalW;
}

float interleavedGradientNoise(vec2 pixel) {
    return fract(52.9829189 * fract(0.06711056 * pixel.x + 0.00583715 * pixel.y));
}

// ============================================================
// Slab intersection
// ============================================================

vec2 intersectSlab(vec3 ro, vec3 rd, float H) {
    if (abs(rd.y) < 1e-6) {
        if (abs(ro.y) < H) return vec2(0.0, 200.0);
        else return vec2(0.0, -1.0);
    }
    float t1 = (-H - ro.y) / rd.y;
    float t2 = (H - ro.y) / rd.y;
    float tmin = min(t1, t2);
    float tmax = max(t1, t2);
    tmin = max(0.0, tmin);
    return vec2(tmin, tmax);
}

void main() {
    vec2 ndc = v_uv * 2.0 - 1.0;
    vec4 target = u_invVP * vec4(ndc, 1.0, 1.0);
    vec3 rd = normalize(target.xyz / target.w - u_camPos);
    vec3 ro = u_camPos;

    // Slab intersection for galactic plane where nebulae exist
    float slab_H = 3.0; // Nebulae are close to plane
    vec2 t_bounds = intersectSlab(ro, rd, slab_H);

    float transmittance = 1.0;
    vec3 accumulated_emission = vec3(0.0);
    float front_depth = -1.0;

    if (t_bounds.y > t_bounds.x && u_nebulaWeight > 0.001) {
        float t = t_bounds.x;
        float t_end = min(t_bounds.y, 150.0);

        int steps = 36;
        float dt = (t_end - t) / float(steps);

        vec2 pixel = gl_FragCoord.xy;
        float jitter = interleavedGradientNoise(pixel);
        t += dt * jitter;

        for (int i = 0; i < 36; i++) {
            if (t > t_end || transmittance < 0.01) break;

            vec3 p = ro + rd * t;
            vec4 p_local_4 = u_galaxyModel * vec4(p, 1.0);
            vec3 p_local = p_local_4.xyz;

            float local_density = 0.0;
            vec3 local_emission = vec3(0.0);

            // Check against all nebulae bounding spheres
            for(int j = 0; j < u_numNebulae; j++) {
                vec3 n_pos = u_nebulae_pos[j].xyz;
                float n_rad = u_nebulae_pos[j].w;
                float dist = distance(p_local, n_pos);
                
                if (dist < n_rad) {
                    // Normalize distance
                    float d_norm = dist / n_rad;
                    
                    // Base falloff (core is dense, edges are diffuse)
                    float falloff = 1.0 - smoothstep(0.0, 1.0, d_norm);
                    
                    if (falloff > 0.01) {
                        // Procedural noise for irregular shapes
                        // Use a domain warp for filamentary look
                        float ns = 1.8;
                        vec3 p_noise = p_local * ns;
                        
                        // Large scale cloud shape
                        float n_large = fbm3(p_noise + vec3(float(j)*1.1));
                        
                        // Medium scale clumps
                        float n_med = fbm5(p_noise * 2.5 + vec3(float(j)*2.3));
                        
                        // Shape cloud using noise + falloff
                        float shape = n_large * 0.6 + n_med * 0.4;
                        
                        // Lowered threshold to ensure clouds are clearly visible and dense
                        float cloud_density = smoothstep(0.15, 0.6, shape * falloff);
                        
                        if (cloud_density > 0.01) {
                            vec4 c_data = u_nebulae_col[j];
                            vec3 color = c_data.rgb;
                            float strength = c_data.a;
                            
                            // Boosted emission multiplier to stand out against 2M stars
                            float em = cloud_density * strength * 15.0;
                            
                            local_density += cloud_density * strength * 1.5;
                            local_emission += color * em;
                        }
                    }
                }
            }

            if (local_density > 0.001) {
                if (front_depth < 0.0) {
                    front_depth = t;
                }
                float step_opacity = local_density * dt * 0.6; // Increased opacity
                float step_transmittance = exp(-step_opacity);
                
                // Additive emission heavily modified by weight
                accumulated_emission += local_emission * dt * u_nebulaWeight * transmittance;
                transmittance *= step_transmittance;
            }

            t += dt;
        }
    }
    
    // Smooth fade in by u_nebulaWeight to prevent popping
    transmittance = mix(1.0, transmittance, u_nebulaWeight);

    // Encode front depth as linear distance
    float encoded_depth = (front_depth < 0.0) ? 0.0 : front_depth / 200.0;

    fragColor = vec4(accumulated_emission, transmittance);
    fragDepth = encoded_depth;
}
