#version 330

in vec3 in_position;
in vec3 in_color;
in float in_size;
in float in_brightness;

out vec3 v_color;

uniform float u_camDistance;
uniform float u_azimuth;
uniform float u_diskSquish;
uniform float u_aspectRatio;
uniform float u_visibility;
uniform float u_galaxyAngle;

void main() {
    float fov_zoom = 2.0; // Fixed to match the black hole raymarcher
    float cam_radius = max(u_camDistance * 12.0, 0.1);
    float cam_height = mix(0.1, 5.0, max(u_diskSquish, 0.02));
    
    vec3 ray_origin = vec3(
        sin(u_azimuth) * cam_radius,
        cam_height,
        cos(u_azimuth) * cam_radius
    );
    
    vec3 forward = normalize(vec3(0.0) - ray_origin);
    vec3 right = normalize(cross(vec3(0.0, 1.0, 0.0), forward));
    vec3 up = cross(forward, right);
    
    // Apply global galaxy rotation around Y axis
    float cos_g = cos(u_galaxyAngle);
    float sin_g = sin(u_galaxyAngle);
    vec3 rotated_pos = vec3(
        in_position.x * cos_g - in_position.z * sin_g,
        in_position.y,
        in_position.x * sin_g + in_position.z * cos_g
    );
    
    // Transform point to view space (camera looking down -Z)
    vec3 diff = rotated_pos - ray_origin;
    vec3 view_pos = vec3(
        dot(diff, right),
        dot(diff, up),
        -dot(diff, forward)
    );
    
    float zNear = 0.1;
    float zFar = 10000.0;
    
    // Standard perspective projection matching the manual ray origin
    gl_Position.x = view_pos.x * fov_zoom / u_aspectRatio;
    gl_Position.y = view_pos.y * fov_zoom;
    gl_Position.z = (view_pos.z * (zFar + zNear) + 2.0 * zFar * zNear) / (zNear - zFar);
    gl_Position.w = -view_pos.z;
    
    // Size attenuation based on distance
    gl_PointSize = in_size * fov_zoom / max(0.1, -view_pos.z) * 100.0;
    
    // Pass color out (fade out slightly with distance, fade in with u_visibility)
    v_color = in_color * in_brightness * u_visibility;
}
